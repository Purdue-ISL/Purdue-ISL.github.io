#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <openssl/sha.h>
#include <openssl/des.h>
#include <time.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/utsname.h>

#define AS_REQ          1
#define AS_REP          2
#define AS_ERR          3
#define AP_REQ          4
#define AP_REP          5
#define AP_ERR          6
#define KRB_PRV         7
#define APP_DATA_REQ    14
#define APP_DATA        15
#define APP_TERMINATE   16
#define ERR             -1
#define LIFETIME        3600
#define LIFETIME2       6
#define CONV            300
#define STICKET         104
#define SCRED           168
#define SAUTH           48
#define MINENC          20
#define MAXENC          984
#define BLOCK_SIZE      972
#define SHA1_SIZE	20

struct ticket
{
        DES_cblock kcs;
        unsigned char client_id[40];
        unsigned long client_ipadd;
        unsigned char server_id[40];
        time_t ts2;
        short lt2;
};

struct credential
{
        DES_cblock kcs;
        unsigned char server_id[40];
        time_t ts2;
        short lt2;
        int tkt_length;
        unsigned char tkt_serv[STICKET];
};

struct as_req
{
        short type;
        unsigned char client_id[40];
        unsigned char server_id[40];
        time_t ts1;
};

struct as_rep
{
        short type;
        short cred_length;
        unsigned char cred[SCRED];
};

struct as_err
{
	short type;
	unsigned char client_id[40];
};

struct auth
{
        unsigned char client_id[40];
        unsigned long client_ipadd;
        time_t ts3;

};

struct ap_req
{
        short type;
        short tkt_length;
        short auth_length;
        unsigned char tkt_serv[STICKET];
        unsigned char auth[SAUTH];
};

struct ap_rep
{
        short type;
        short nonce_length;
        unsigned char nonce[MINENC];
};

struct ap_err
{
	short type;
	unsigned char client_id[40];
};

struct krb_prv
{
        short type;
        short prv_length;
        unsigned char prv[MAXENC];
};

struct pdata
{
        short   type;
        short    packet_length;
        short     pid;
        unsigned char    data[BLOCK_SIZE];
};
