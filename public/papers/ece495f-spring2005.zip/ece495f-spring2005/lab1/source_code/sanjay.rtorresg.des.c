#include <openssl/des.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#define ERR -1
#define BLOCK 8
#define RSIZE 8
#define ENC 1
#define DEC 0

long pack(unsigned char *msg) 
{
	long lmsg=0;

	lmsg = (long)(*msg++);
	lmsg = (((long)(*msg++)) << 8) | lmsg;
	lmsg = (((long)(*msg++)) << 16) | lmsg;
	lmsg = (((long)(*msg++)) << 24) | lmsg;

	return(lmsg);
}

long packx(unsigned char *msg,int num)
{
	long lmsg = 0;
	int i;
	
	for (i=0;i<num;i++) {
		lmsg = (((long)(*msg++)) << (i*8)) | lmsg;
	}
	return(lmsg);
}

int unpack(long lmsg, unsigned char *msg)
{
	*(msg++) = (char)(lmsg & 0xff);
	*(msg++) = (char)((lmsg >> 8) & 0xff);
	*(msg++) = (char)((lmsg >> 16) & 0xff);
	*(msg++) = (char)((lmsg >> 24) & 0xff);

}

unsigned char *to_hex(unsigned char *key,unsigned char test1[]) 
{
	char test[3];
	int i;
	
	for(i=0;i<8;i++) {
		test[0] = *key++;
		test[1] = *key++;
		test1[i] = strtol(test,NULL,16);
	}
	return(test1);
}

int main(int argc, char *argv[])
{
	int	infd,outfd,decfd,k,j,w,i;
	int	bytes_read,bytes_write;
	unsigned char	rbuff[BLOCK],wbuff[BLOCK];
	unsigned char	*in,*out;
	long	in1,in2;
	long	v1,v2;
	long	blk[2],dec[2];
	long	fsize;
	char	str[30];
	static unsigned char key1[16],key2[16];
	struct	stat	buffer;	
//	static unsigned char tt_key[8] = {0x40,0xfe,0xdf,0x38,0x6d,0xa1,0x3d,0x57};
//	static unsigned char cbc_iv[8] = {0xfe,0xdc,0xba,0x98,0x76,0x54,0x32,0x10};
	unsigned char cbc_key[8];
	unsigned char iv[8];
	
	des_key_schedule key;

	to_hex(argv[1],iv);
	to_hex(argv[2],cbc_key);

		
	if (argc != 5)
		printf("you are missing an argument\n");

	memset(rbuff,0,BLOCK);
	memset(wbuff,0,BLOCK);

//	(unsigned char *)iv = &(cbc_iv[0]);
	
	v1 = pack(iv);
	v2 = pack(iv+4);

//	if ((k = des_set_key_checked(&cbc_key,key)) != 0)
	if ((k = des_set_key_checked((const_des_cblock *)cbc_key,key)) != 0)
	
		printf("\nkey error\n");

	if( (infd = open(argv[3],O_RDONLY)) == ERR)
		printf("\nerror opening file1\n");

	fstat(infd,&buffer);
	fsize = buffer.st_size;	

	if( (outfd = open(argv[4],O_RDWR|O_CREAT,S_IWUSR)) == ERR)
		printf("\nerror opening file2\n");

	while( (bytes_read = read(infd,rbuff,BLOCK)) )
	{
		(unsigned char *)in = &(rbuff[0]);

		if (bytes_read == BLOCK)
		{
			in1 = pack(in);
			in2 = pack(in+4);
		} else if (bytes_read <=4 ) {
			in1 = packx(in,bytes_read);
			in2 = 0;
		} else {
			in1 = packx(in,4);
			in2 = packx(in+4,bytes_read-4);
		}
	
		blk[0] = in1 ^ v1;
		blk[1] = in2 ^ v2;

		des_encrypt1(blk,key,ENC);

		(unsigned char *)out = &(wbuff[0]);
		unpack(blk[0],out);
		unpack(blk[1],out+4);
		

		if( (bytes_write = write(outfd,wbuff,BLOCK)) == ERR)
			printf("\nerror writing to file2\n");
		
		v1 = pack(out);
		v2 = pack(out+4);

		memset(rbuff,0,RSIZE);
		memset(wbuff,0,RSIZE);
	}

	close(infd);
	close(outfd);

	sprintf(str,"chmod 600 %s",argv[4]);
	system(str);

}
