#include "header.h"

struct genpacket
{
        short type;
        unsigned char payload[1008];
};
                                                                                                                                                             
unsigned char *to_hex(unsigned char *key,unsigned char test1[])
{
        char test[3];
        int i;
                                                                                                                                                             
        for(i=0;i<8;i++) {
                test[0] = *key++;
                test[1] = *key++;
                test1[i] = strtol(test,NULL,16);
        }
        return(test1);
}
                                                                                                                                                             
unsigned char *mysha1(char *file, unsigned char wbuff[]) {
        int i;
        int infd,outfd;
        int bytes_read,bytes_write;
        unsigned char rbuff[8];
        SHA_CTX c;
                                                                                                                                                             
        memset(wbuff,0,sizeof(wbuff));
        if( (infd = open(file,O_RDONLY)) == ERR)
                printf("\nerror opening file1\n");
        SHA1_Init(&c);
        while( bytes_read = read(infd,rbuff,sizeof(rbuff)) )
        {
                SHA1_Update(&c,rbuff,bytes_read);
                memset(rbuff,0,sizeof(rbuff));
        }
        SHA1_Final(wbuff,&c);
        return(wbuff);
}
                                                                                                                                                             
char **my_addr(void)
{
        struct hostent *hptr;
        struct utsname myname;
        if(uname(&myname) < 0)
                return (NULL);
        if((hptr = gethostbyname(myname.nodename)) == NULL)
                return (NULL);
        return (hptr->h_addr_list);
}

int main(int argc, char **argv)
{
        int     sockfd,sockfd2;
        int     debug = 0;
        struct  sockaddr_in     asaddr,servaddr;
        struct  genpacket       generic;
        struct  hostent 	*asip,*srvip;
        char    **ptr,**localip;
        char    str[16];
        unsigned short  port;
	struct	as_req		asreq;
	struct	as_rep		*asrep;
        struct  credential      crede;
        struct  ticket          tkt;
	struct	auth		authc;
	struct	ap_req		apreq;
	struct	ap_rep		*aprep;
	struct	ap_err		aperr;
	struct	krb_prv		*kenc_in, kenc_out;
	struct	pdata		pdata;
	unsigned short	credsize,tktsize,authsize,prvsize;
        DES_key_schedule key_cli,key_kcs;
	DES_cblock      sesskey,ivec;
	unsigned char cbc_alice[8];
        static unsigned char zero[8] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	int i,j,trans,recv,error;
	time_t currtime;
	unsigned char nonce[20],wbuff[SHA1_SIZE];
	unsigned char client_id[40],server_id[40];
	unsigned long validity,sender_ip,snonce;
        FILE    *fp;
        short     pid;
	int wip = 0, wid = 0, wtime = 0;

        //check input arguments
        if ((argc < 9) || (argc > 12)) {
                printf("usage: client <authservername> <authserverport> <authserverkey> <servername> <serverport> <output file> <clientID> <serverID>\n");
                exit(0);
        }
        
        if(((argc == 10) || (argc == 12)) && (strcmp(argv[9],"-DDEBUG") == 0)) {
                debug = 1;
        }
	if ( (argc == 12) && ((strcmp(argv[10],"-T1") == 0)) ) {
		wip = atoi(argv[11]);
	} 
	else if ((argc == 12) && ((strcmp(argv[10],"-T2") == 0))) {
		wid = 1;
	}
	else if ((argc == 12) && ((strcmp(argv[10],"-T3") == 0))) {
		wtime = 3600 * atoi(argv[11]);
	}
        //get client en server ID from command line;
        bzero(&client_id, sizeof(client_id));
        bzero(&server_id, sizeof(server_id));
        strcpy(client_id,argv[7]);
        strcpy(server_id,argv[8]);

	//get the keys from the command line argument
	to_hex(argv[3],cbc_alice);

	//Authentication Server settings
	port = atoi(argv[2]);
        asip = (struct hostent *)gethostbyname(argv[1]);
        ptr = asip->h_addr_list;
        bzero(&asaddr, sizeof(asaddr));
        asaddr.sin_family = AF_INET;
        asaddr.sin_port = htons(port);
        inet_ntop(AF_INET, *ptr, str, sizeof(str));

        if (inet_pton(AF_INET, str, &asaddr.sin_addr) == 0) {
                if(debug) {
                        printf("wrong authentication server name\n");
                }
                printf("ABORT\n");
                exit(0);
        }

        if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == ERR) {
                if(debug) {
                        printf("Error while opening AS socket\n");
                }
                printf("ABORT\n");
                exit(0);
        }

	//Application Server settings
        port = atoi(argv[5]);
        srvip = (struct hostent *)gethostbyname(argv[4]);
        ptr = srvip->h_addr_list;
        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_port = htons(port);
        inet_ntop(AF_INET, *ptr, str, sizeof(str));

        if (inet_pton(AF_INET, str, &servaddr.sin_addr) == 0) {
                if(debug) {
                        printf("wrong application server name\n");
                }
                printf("ABORT\n");
                exit(0);
        }

        if ( (sockfd2 = socket(AF_INET, SOCK_DGRAM, 0)) == ERR) {
                if(debug) {
                        printf("Error while opening server socket\n");
                }
                printf("ABORT\n");
                exit(0);
        }

        //Set the keys for ALICE
        if ((j = DES_set_key_checked(&cbc_alice,&key_cli)) != 0)
        {
		if(debug) {
                	printf("Incorrect predefined authserver key\n");
		}
		printf("ABORT\n");
                exit(0);
        }

	memcpy(ivec,zero,sizeof(ivec));

	//Preparing message AS_REQ
        bzero(&asreq, sizeof(asreq));
        asreq.type       = htons(AS_REQ);
        memcpy(asreq.client_id,client_id,sizeof(client_id));
        memcpy(asreq.server_id,server_id,sizeof(server_id));

        if ( (sendto(sockfd,&asreq,sizeof(asreq),0, (struct sockaddr *) &asaddr, sizeof(asaddr))) == ERR) {
                if(debug) {
                        printf("Error - packet size too long\n");
                }
                printf("ABORT\n");
                exit(0);
        }

	//Receiving AS_REP
	bzero(&generic, sizeof(generic));
        if ( (recv = recvfrom(sockfd, &generic, sizeof(generic),0, NULL, NULL)) == ERR) {
                if(debug) {
                        printf("error receiving packet\n");
                }
                printf("ABORT\n");
                exit(0);
        }

       	if (ntohs(generic.type) == AS_REP) {
        	if(debug) {
        		printf("AS_REP received\n");
        	}
        } else if (ntohs(generic.type) == AS_ERR) {
        	if(debug) {
        		printf("AS_ERR received - from Authentication Server\n");
        	}
        	printf("ABORT\n");
        	exit(0);
     	} else {
      		if(debug) {
   			printf("Expecting AS_REP or AS_ERR\n");
			printf("I'm receiving packet type = %d\n",ntohs(generic.type));
    		}
       		printf("ABORT\n");
        	exit(0);
    	}

	//openning AS_REP message
	asrep = (struct as_rep *) &generic;
	credsize = ntohs(asrep->cred_length);
	
	//getting space for credential
	bzero(&crede,sizeof(struct credential));
	memcpy(ivec,zero,sizeof(zero));
	DES_ncbc_encrypt(asrep->cred,(unsigned char *)&crede,credsize,&key_cli,&ivec,DES_DECRYPT);

	//get session key
	memcpy(sesskey,crede.kcs,sizeof(crede.kcs));

        //check Session key
        if ((j = DES_set_key_checked(&sesskey,&key_kcs)) != 0)
        {
		if(debug) {
             		printf("Wrong session key received\n");
               		printf("Session key received:\t");
              		for (i=0;i<sizeof(sesskey);i++) {
                   		printf("%x",sesskey[i]);
               		}
			printf("\n");
		}
                printf("ABORT\n");
                exit(0);
        }

	//printing session key generated
	if (debug) {
		printf("Session key received:\t");
		for (i=0;i<sizeof(sesskey);i++) {
         		printf("%x",sesskey[i]);
        	}
		printf("\n");
	}

	//check server ID on ticket
	if (memcmp(crede.server_id,server_id,sizeof(server_id)) == 0)
        {
		if (debug) {
			printf("Server ID of application server is correct\n");
		}
        } else {
		if (debug) {
			printf("Server ID of application server is worng = %s\n",crede.server_id);
		}
		printf("ABORT\n");
		exit(0);
        }

	//check lifetime of session key (ticket)
	time(&currtime);
	validity = (crede.ts2) + ntohs(crede.lt2);
	if(currtime < validity)
        {
		if (debug) {
			printf("Session key still valid\n");
		}
        } else {
		if (debug) {
			printf("Session key has expired\n");
			printf("timestamp = %u, lifetime = %u, currtime = %u \n",crede.ts2,ntohs(crede.lt2),currtime);
		}
		printf("ABORT\n");
		exit(0);
        }

	//forming authenticator
	bzero(&authc,sizeof(struct auth));
	memcpy(authc.client_id,client_id,sizeof(client_id));

	/* test case wrong client ID */
	if(wid) {
		if(debug) {
			printf("client ID before changing is %s\n",authc.client_id);
		}
		bzero(&authc.client_id,sizeof(authc.client_id));
		memcpy(authc.client_id,argv[11],sizeof(argv[11]));
	}
	/* end testcase */
	
	if(debug) {
		printf("client ID sent to server is %s\n",authc.client_id);	
	}

	localip = my_addr();

	sender_ip = *(unsigned long *) (localip[0]);

	/* test case wrong client ip address */
	if(debug) {
		printf("client ip before adding %d = %u\n",wip,sender_ip);	
	}
	sender_ip += wip;
	/* end testcase */

	if(debug){
		printf("local ip address in network byte order = %u\n",sender_ip);
	}

	authc.client_ipadd = sender_ip;
	time(&authc.ts3);

	/* Test cases - modified timestamp for session key*/
        if(debug) {
        	printf("timestamp before substracting %d seconds = %u\n",wtime,authc.ts3);
        }
        authc.ts3 -= wtime;
        /* End Testcase */

	snonce = authc.ts3;
	if(debug) {
		printf("nonce generated for server = %u\n",snonce);
	}

	//Preparing AP_REQ message
	bzero(&apreq,sizeof(struct ap_req));
	apreq.type = htons(AP_REQ);
	apreq.tkt_length = crede.tkt_length;	//tkt_length already in network byte order

	authsize = sizeof(struct auth);
	if ((authsize % 8) != 0) {
		authsize += 4;
	}

	apreq.auth_length = htons(authsize);
	memcpy(apreq.tkt_serv,crede.tkt_serv,ntohs(crede.tkt_length));

	//encrypting authenticator
	memcpy(ivec,zero,sizeof(zero));
	DES_ncbc_encrypt((unsigned char *)&authc,(unsigned char *)&apreq.auth,authsize,&key_kcs,&ivec,DES_ENCRYPT);

	//Send AP_REQ to server
        if ( (sendto(sockfd2,&apreq,sizeof(apreq),0, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
                if(debug) {
                        printf("Error - packet size too long\n");
                }
                printf("ABORT\n");
                exit(0);
        }
	
	if(debug) {
		printf("AP_REQ sent\n");
	}

	bzero(&generic, sizeof(generic));

	//Receiving AP_REP
        if ( (recvfrom(sockfd2, &generic, sizeof(generic),0, NULL, NULL)) == ERR) {
                if(debug) {
                        printf("error receiving packet\n");
                }
                printf("ABORT\n");
                exit(0);
        }

        if (ntohs(generic.type) != AP_REP) {
                if(debug) {
                        printf("Expecting AP_REP\n");
			printf("I'm receiving packet type = %d\n",ntohs(generic.type));
                }
                printf("ABORT\n");
                exit(0);
        } else {
                if(debug) {
                        printf("AP_REP received\n");
                }
        }

	//check lifetime of session key (ticket)
	time(&currtime);
	if(currtime < validity)
        {
		if (debug) {
			printf("Session key still valid\n");
		}
        } else {
		if (debug) {
			printf("Session key has expired\n");
			printf("currtime = %u, validity = %u \n",currtime,validity);
		}
		printf("ABORT\n");
		exit(0);
        }

	//openning AP_REP message
        aprep = (struct ap_rep *) &generic;
	memcpy(ivec,zero,sizeof(zero));
	DES_ncbc_encrypt(aprep->nonce,(unsigned char *)&nonce,ntohs(aprep->nonce_length),&key_kcs,&ivec,DES_DECRYPT);

	//check the nonce reply
        if( atoi(nonce) == (snonce + 1))
        {
                if (debug) {
                        printf("Nonce answered correctly\n");
                }
        } else {
                if (debug) {
                        printf("Nonce answer is wrong\n");
                        printf("Nonce answer received is = %u, but expecting %u\n",atoi(nonce),(snonce + 1));
                }
                //sending AP_ERR to server
		bzero(&aperr,sizeof(struct ap_err));
		aperr.type = htons(AP_ERR);
 		memcpy(aperr.client_id,client_id,sizeof(client_id));
		if ( (sendto(sockfd2,&aperr,sizeof(struct ap_err),0, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
			if(debug) {
				printf("Error - packet size too long\n");
			}
		}
		printf("ABORT\n");
		exit(0);
        }

//---- Authentication is Done -------
//	loading data to pdata struct
	bzero(&kenc_out,sizeof(struct krb_prv));
	bzero(&pdata, sizeof(struct pdata));
    	pdata.type = htons(APP_DATA_REQ);

       	//preparing KRB_PRV packet
	kenc_out.type = htons(KRB_PRV);
	kenc_out.prv_length = htons(sizeof(struct pdata));

	memcpy(ivec,zero,sizeof(zero));
	DES_ncbc_encrypt((unsigned char *)&pdata,(unsigned char *)&kenc_out.prv,sizeof(struct pdata),&key_kcs,&ivec,DES_ENCRYPT);

       	//send APP_DATA_REQ packet
        if ( (sendto(sockfd2,&kenc_out,sizeof(struct krb_prv),0, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
        	if(debug) {
         		printf("Error - packet size too long\n");
                }
                printf("ABORT\n");
                exit(0);
        }
	
	if(debug) {
		printf("APP_DATA_REQ sent\n");
	}

        fp = fopen(argv[6],"w");
        pid = 0;
        bzero(&generic, sizeof(generic));
	generic.type = htons(KRB_PRV);

	//Getting APP_DATA packets
        while(ntohs(generic.type) == KRB_PRV) {
        	bzero(&generic, sizeof(generic));
       		bzero(&pdata, sizeof(struct pdata));
        	if ( recvfrom(sockfd2, &generic, sizeof(generic),0,NULL,NULL) == ERR) {
        		if(debug) {
       				printf("error receiving packet\n");
        		}
       	 		printf("ABORT\n");
        		exit(0);
		}
        	if (ntohs(generic.type) == KRB_PRV) {
        		if(debug) {
        			printf("KRB_PRV received\n");
        		}
        	} else if (ntohs(generic.type) == AP_ERR) {
        		if(debug) {
        			printf("AP_ERR received - aborting\n");
        		}
        		printf("ABORT\n");
        		exit(0);
     		} else {
      			if(debug) {
   				printf("Expecting KRB_PRV or AP_ERR\n");
				printf("I'm receiving packet type = %d\n",ntohs(generic.type));
    			}
       			printf("ABORT\n");
        		exit(0);
    		}

	//check lifetime of session key (ticket)
        	time(&currtime);
        	if(currtime < validity)
        	{
        		if (debug) {
                		printf("Session key still valid\n");
           		}
     		} else {
			if (debug) {
              			printf("Session key has expired\n");
				printf("currtime = %u, validity = %u \n",currtime,validity);
              		}
			printf("ABORT\n");
                	exit(0);
        	}

        //Opening KRB_PRV packet
        	kenc_in = (struct krb_prv *) &generic;
        	prvsize = ntohs(kenc_in->prv_length);  //size of ticket

       	//getting space for data
        	memcpy(ivec,zero,sizeof(zero));
        	DES_ncbc_encrypt(kenc_in->prv,(unsigned char *)&pdata,prvsize,&key_kcs,&ivec,DES_DECRYPT);

        //checking IP address of client - CORRECT - CHECK CLIENT IP ADDRESS
	//geting DATA packet
		if (ntohs(pdata.type) == APP_DATA) {
        		if(debug) {
      				printf("APP_DATA Received - pid = %d\n",ntohs(pdata.pid));
  			}
 		} else if (ntohs(pdata.type) == APP_TERMINATE) {
     			if(debug) {
    				printf("APP_TERMINATE received\n");
      			}
			break;
   		} else {
     			if(debug) {
    				printf("Expecting APP_DATA or APP_TERMINATE\n");
	 			printf("I'm receiving packet type = %d\n",ntohs(pdata.type));
      			}
			printf("ABORT\n");
    			exit(0);
		}

	//Verifying pid		
                if((ntohs(pdata.pid) != pid+1)) {
                        if(debug) {
                                printf("transmission error, pid sequence incorrect\n");
				printf("Expecting pid = %d but receiving pid = %d",pid+1,ntohs(pdata.pid));
                        }
                        printf("ABORT\n");
                        exit(0);
                }

                pid = ntohs(pdata.pid);
                fwrite(pdata.data,sizeof(char),ntohs(pdata.packet_length),fp);
        }

	//Only gets to here if TERMINATE packet received

        fclose(fp);
        mysha1(argv[6],wbuff);

        if ( (memcmp(pdata.data,wbuff,sizeof(wbuff)) == 0) ) {
                if(debug) {
                        printf("checksum correct\n");
                }
        } else {
                if(debug) {
                        printf("incorrect checksum\n");
			printf("Expecting checksum =\t");
			for(i=0;i<SHA1_SIZE;i++) {
				printf("%x",wbuff[i]);
			}
			printf("\nReceiving checksum = \t");
			for(i=0;i<SHA1_SIZE;i++) {
				printf("%x",pdata.data[i]);
			}
                }
                printf("\nABORT\n");
                exit(0);
        }

        if(debug) {
                printf("file transmission completed\n");
        }

        printf("OK\n");
        exit(0);

}	
