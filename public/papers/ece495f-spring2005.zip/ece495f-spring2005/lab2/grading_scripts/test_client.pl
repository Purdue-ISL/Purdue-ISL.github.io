#!/usr/bin/perl

#Initialize some variables
$sername = "msee190pc21.ecn.purdue.edu"; #linux server
$sersun = "shay.ecn.purdue.edu"; # sun server
@passwords = ("purdue","purdue","purdue");
$output = "text.recv"; # received file
$original = "test.txt"; # sent file
$COMP = 0;
$serport = 9877; # port for well behave server
$portaltpid = 12331; # port for server that alters pid
$portwrgha =  15220; # port for server thar sends wrong hash
$portpasrq =  17453; # port for server that doesn't send pass req
$password = "purdue";

if ($ARGV[0] eq "C") {
	$COMP = 1;
} else {
	$COMP = 0;
}

#get the client code to test
opendir(DIR, ".");
@clients = grep(/\.client\.c/,readdir(DIR));
closedir(DIR);

#get the server code to test
opendir(DIR, ".");
@servers = grep(/\.server\.c/,readdir(DIR));
closedir(DIR);

#open log file and clean it
open (LOG, ">log.txt") || die "couldn't open the file!";
close(LOG);

#Open results file for writing.
open (LOG, ">>log.txt") || die "couldn't open the file!";

#compile files in case "perl test_client.pl C" executed
@copt = ("-lcrypto");

foreach $filecli (@clients) {
   	($temp,$grb) = split(/\.c$/,$filecli);
  	push(@clic,$temp);
	if ($COMP == 1) {
   		system("gcc","-o","$temp","@copt",$filecli);
	}
}

foreach $fileser (@servers) {
   	($temp,$grb) = split(/\.c$/,$fileser);
   	push(@serc,$temp);
	if ($COMP == 1) {
   		system("gcc","-o","$temp","@copt",$fileser);
	}
}

#try client
foreach $filecli (@clic) {
   print ("$filecli\n");
   print LOG ("$filecli\n");

#basic clilin - serlin test
   print ("BASIC CLILIN - SERLIN TEST\n");
   print LOG ("BASIC CLILIN - SERLIN TEST\n");

   open(RES,"./$filecli $sername $serport @passwords $output" . "|");
   @res = <RES>;
	foreach $result (@res) {
		print LOG ("$result");
		print ("$result");	
	}
   close (RES);

#basic clilin - sersun test
   print ("BASIC CLILIN - SERSUN TEST\n");
   print LOG ("BASIC CLILIN - SERSUN TEST\n");

   open(RES,"./$filecli $sersun $serport @passwords $output" . "|");
   @res = <RES>;
   print LOG ("$filecli\n");
	foreach $result (@res) {
		print LOG ("$result");
		print ("$result");	
	}
   close (RES);


#compare file transmitted and received
   open(DIF,"diff $output $original" . "|");
   @dif = <DIF>;
   print LOG ("@dif\n");
   close(DIF);

#server modified - altered packet id 
   print ("SERVER MODIFIED - ALTERED PACKET ID\n");
   print LOG ("SERVER MODIFIED - ALTERED PACKET ID\n");

   open(RES,"./$filecli $sername $portaltpid @passwords $output" . "|");
   @res = <RES>;
   print LOG ("$filecli\n");
	foreach $result (@res) {
		print LOG ("$result");
		print ("$result");	
	}
   close (RES);

#server modified - wrong hash 
   print ("SERVER MODIFIED - WRONG HASH\n");
   print LOG ("SERVER MODIFIED - WRONG HASH\n");

   open(RES,"./$filecli $sername $portwrgha @passwords $output" . "|");
   @res = <RES>;
   print LOG ("$filecli\n");
	foreach $result (@res) {
		print LOG ("$result");
		print ("$result");	
	}
   close (RES);

#server modified - different PASS REQ
   print ("SERVER MODIFIED - DIFFERENT PASS REQ\n");
   print LOG ("SERVER MODIFIED - DIFFERENT PASS REQ\n");

   open(RES,"./$filecli $sername $portpasrq @passwords $output" . "|");
   @res = <RES>;
   print LOG ("$filecli\n");
	foreach $result (@res) {
		print LOG ("$result");
		print ("$result");	
	}
   close (RES);

}

close(LOG);
