#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <openssl/crypto.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>

#define ERR -1
#define RSIZE 8

int mafile()
{
	int j;
	int i;
	int power=1;
	char str[10];
	int outfd;

        for(i=1;i<8;i++)
        {
                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.txt",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file1\n");

		power <<=1;
                for (j=0;j<power;j++)
                        write(outfd,"A",1);
                close(outfd);

                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.rsa",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file2\n");	
		close(outfd);

                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.rsa.clr",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file3\n");	
		close(outfd);

        }
        system("chmod 600 file*");
}

int main()
{
	RSA *key;
	unsigned char rbuff[RSIZE];
	unsigned char wbuff[256];
	unsigned char exbuff[256];
	int num;
	int i;
	int infd,outfd;
	int bytes_read,bytes_write;
	struct timeval  start,end,lapsed;
	float   acum=0.0;
	char stri[10],stro[10];
	static const char rnd_seed[] = "string to make the random number generator think it has entropy";

	memset(rbuff,0,RSIZE);
       	memset(wbuff,0,256);
	RAND_seed(rnd_seed, sizeof rnd_seed);
	if( (key = RSA_generate_key(2048,3,NULL,NULL)) == NULL)
		printf("\nerror generating key\n");

	mafile();

	printf("RSA encryption\n");
	for (i=1;i<8;i++)
	{
		sprintf(stri,"file%d.txt",i);
		sprintf(stro,"file%d.rsa",i);
        	if( (infd = open(stri,O_RDONLY)) == ERR)
                	printf("\nerror opening file1\n");

        	if( (outfd = open(stro,O_WRONLY|O_CREAT,S_IWUSR)) == ERR)
                	printf("\nerror opening file2\n");

        	while( (bytes_read = read(infd,rbuff,RSIZE)) )
		{
			gettimeofday(&start,0);
			num = RSA_public_encrypt(RSIZE,rbuff,wbuff,key,RSA_PKCS1_PADDING);
			gettimeofday(&end,0);

                	if (start.tv_usec > end.tv_usec) {
                        	end.tv_usec += 1000000;
                        	end.tv_sec--;
                	}
                	lapsed.tv_usec = end.tv_usec - start.tv_usec;
                	acum += lapsed.tv_usec;

                	if( (bytes_write = write(outfd,wbuff,num)) == ERR)
                        	printf("\nerror writing to file2\n");
		}
		printf("%f\n",acum);
		acum=0.0;
		close(outfd);
		close(infd);
	}

	printf("RSA decryption\n"); 
	for (i=1;i<8;i++)
	{
		sprintf(stri,"file%d.rsa",i);
		sprintf(stro,"file%d.rsa.clr",i);
        	if( (infd = open(stri,O_RDONLY)) == ERR)
                	printf("\nerror opening file2\n");

      		if( (outfd = open(stro,O_WRONLY|O_CREAT,S_IWUSR)) == ERR)
                	printf("\nerror opening file3\n");

		memset(rbuff,0,RSIZE);
       		memset(wbuff,0,256);
		memset(exbuff,0,256);

		while( (bytes_read = read(infd,exbuff,sizeof(exbuff))) )
        	{
			gettimeofday(&start,0);
			num = RSA_private_decrypt(bytes_read,exbuff,wbuff,key,RSA_PKCS1_PADDING);
			gettimeofday(&end,0);

                	if (start.tv_usec > end.tv_usec) {
                        	end.tv_usec += 1000000;
                        	end.tv_sec--;
                	}

                	lapsed.tv_usec = end.tv_usec - start.tv_usec;
                	acum += lapsed.tv_usec;

                	if( (bytes_write = write(outfd,wbuff,num)) == ERR)
                        	printf("\nerror writing to file2\n");
		}
		printf("%f\n",acum);
		acum=0.0;
        	close(infd);
        	close(outfd);
	}
    	RSA_free(key);
}
