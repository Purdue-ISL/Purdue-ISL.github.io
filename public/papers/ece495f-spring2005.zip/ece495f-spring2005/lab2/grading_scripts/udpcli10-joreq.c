#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <sys/stat.h>
#include <openssl/sha.h>
#include <fcntl.h>
#include <netdb.h>
#include <math.h>

#define SHA1_SIZE       20
#define PASS_SIZE       50
#define BLOCK_SIZE      1000
#define ERR 		-1
#define JOIN_REQ        1
#define PASS_REQ        2
#define PASS_RESP       3
#define PASS_ACCEPT     4
#define DATA            5
#define TERMINATE       6
#define REJECT		7
#define DUMMY		12

struct genpacket
{
	short	header;
	int	plength;
//	int	fsize;
	int	pid;
	unsigned char	data[1000];	
};

struct pdata
{
        short   header;
        int     plength;
//        int     fsize;
        int     pid;
        unsigned char    data[BLOCK_SIZE];
};
struct ppass
{
        short   header;
        int     plength;
        unsigned char    data[PASS_SIZE];
};
struct pterm
{
        short   header;
        int     plength;
        unsigned char    data[SHA1_SIZE];
};
struct jr
{
        short   header;
        int     plength;
};
struct pr
{
        short   header;
        int     plength;
};
struct pa
{
        short   header;
        int     plength;
};
struct rej
{
        short   header;
        int     plength;
};

unsigned char *mysha1(char *file, unsigned char wbuff[]) {
        int i;
        int infd,outfd;
        int bytes_read,bytes_write;
        unsigned char rbuff[8];
        SHA_CTX c;

        memset(wbuff,0,sizeof(wbuff));
        if( (infd = open(file,O_RDONLY)) == ERR)
                printf("\nerror opening file1\n");
        SHA1_Init(&c);
        while( bytes_read = read(infd,rbuff,sizeof(rbuff)) )
        {
                SHA1_Update(&c,rbuff,bytes_read);
                memset(rbuff,0,sizeof(rbuff));
        }
        SHA1_Final(wbuff,&c);
        return(wbuff);
}

unsigned short to_num(unsigned char *key)
{
        int i=0,num=0;
	unsigned short tests=0,acums=0;

	while(*(key+i) != '\0') {
		i++;
	}
	num = i;
        for(i=(num-1);i>=0;i--) {
                tests = (int) *key++;
		tests -= 48;
		tests *= pow(10,i);
		acums += tests;
		tests = 0;
        }

        return(acums);
}

unsigned short size(unsigned char *key)
{
        int i=0,num=0;
                                                                                
        while( *(key+i) != '\0' ) {
                i++;
        }
        return(i);
}

int main(int argc, char **argv)
{
	int	sockfd;
        int     debug = 0;
	int	n,i;
	char	ch;
	struct 	sockaddr_in	servaddr;
	struct	genpacket	recvpacket;
	FILE	*fp;
	int	pid;
        unsigned char   wbuff[SHA1_SIZE];
	struct	hostent	*srvip;
	char	**ptr;
	char	str[16];
	unsigned short 	port;
        struct  pdata   pdata;
        struct  ppass   ppass;
        struct  pterm   *pterm;
        struct  jr      jr;
        struct  pr      pr;
        struct  pa      pa;
        struct  rej     rej;


	if ((argc < 7) || (argc > 8)) {
		printf("usage: udpcli <servername> <serverport> <clientpwd1> <clientpwd1> <clientpwd1> <outfile>\n");
		exit(0);
	}

        if((argc == 8) && (strcmp(argv[7],"-DDEBUG") == 0)) {
                debug = 1;
        }

	port = to_num(argv[2]);

	srvip = (struct hostent *)gethostbyname(argv[1]);
	ptr = srvip->h_addr_list;
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(port);
	inet_ntop(AF_INET, *ptr, str, sizeof(str));

	if (inet_pton(AF_INET, str, &servaddr.sin_addr) == (int)NULL) {
		if(debug) {
			printf("wrong server name\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == ERR) {
		if(debug) {
			printf("Error while opening socket\n");
		}
		printf("ABORT\n");	
		exit(0);
	}
	
	bzero(&jr, sizeof(jr));
	// RDT - Change
	jr.header	= htons(DUMMY);
	//jr.header	= htons(JOIN_REQ);
	// END
	jr.plength	= 0;

	if ( (sendto(sockfd,&jr,sizeof(jr),0, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
		if(debug) {
			printf("Error - packet size too long\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if ( recvfrom(sockfd, &recvpacket, sizeof(recvpacket),0, NULL, NULL) == ERR) {
		if(debug) {
			printf("error receiving packet\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if ( (ntohs(recvpacket.header) != PASS_REQ) || (recvpacket.plength != 0) ) {
		if(debug) {
			printf("no PASS_REQ arrived\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	i = 3;
	while( ntohs(recvpacket.header) == PASS_REQ ) {

		if(debug) {
			printf("PASS_REQ received\n");
		}

		bzero(&ppass, sizeof(ppass));
		ppass.header	= htons(PASS_RESP);
		ppass.plength	= 0;
	
		memcpy(ppass.data,argv[i],size(argv[i]));
		ppass.plength = htonl(size(argv[i]));
		i++;

		if ( (sendto(sockfd,&ppass,sizeof(ppass),0, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
			if(debug) {
				printf("Error - packet size too long\n");
			}
			printf("ABORT\n");	
			exit(0);
		}
	
		if ( recvfrom(sockfd, &recvpacket, sizeof(recvpacket),0, NULL, NULL) == ERR) {
			if(debug) {
				printf("error receiving packet\n");
			}
			printf("ABORT\n");	
			exit(0);
		}	
	}	

	if ( (ntohs(recvpacket.header) == REJECT) && (recvpacket.plength == 0) ) {
		if(debug) {
			printf("Please restart session and introduce the correct password\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if ( (ntohs(recvpacket.header) != PASS_ACCEPT) || (recvpacket.plength != 0) ) {
		if(debug) {
			printf("no PASS_ACCEPT arrived\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if(debug) {
		printf("PASS_ACCEPT received\n");
	}
	
	bzero(&recvpacket, sizeof(recvpacket));
	fp = fopen(argv[6],"w");

	if ( recvfrom(sockfd, &recvpacket, sizeof(recvpacket),0, NULL, NULL) == ERR) { 
		if(debug) {
			printf("error receiving packet\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if (ntohs(recvpacket.header) != DATA) { 
		if(debug) {
			printf("Expecting DATA\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	pid = 0;
	while(ntohs(recvpacket.header) == DATA) {
		if((ntohl(recvpacket.pid) != pid+1)) {
			if(debug) {
				printf("transmission error\n");
			}
			printf("ABORT\n");	
			exit(0);	
		}

		pid = ntohl(recvpacket.pid);
		fwrite(recvpacket.data,sizeof(char),ntohl(recvpacket.plength),fp);
		if(debug) {
			printf("receiving file\n");
		}

		if ( recvfrom(sockfd, &recvpacket, sizeof(recvpacket),0, NULL, NULL) == ERR) { 
			if(debug) {
				printf("error receiving packet\n");
			}
			printf("ABORT\n");
			exit(0);
		}
	}

	if (ntohs(recvpacket.header) != TERMINATE) { 
		if(debug) {
			printf("Expecting TERMINATE\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if(debug) {
		printf("TERMINATE received\n");
	}

	pterm = (struct pterm *) &recvpacket;

	fclose(fp);
	mysha1(argv[6],wbuff);

	if ( (memcmp(pterm->data,wbuff,sizeof(wbuff)) == 0) && (ntohl(pterm->plength) == sizeof(wbuff)) ) {
		if(debug) {
			printf("checksum correct\n");
		}
	} else {
		if(debug) {
			printf("incorrect checksum\n");
		}
		printf("ABORT\n");	
		exit(0);
	}

	if(debug) {
		printf("file transmission completed\n");
	}

	printf("OK\n");	
	exit(0);
}
