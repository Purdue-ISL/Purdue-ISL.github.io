#include <openssl/sha.h>
#include <fcntl.h>
#include <sys/stat.h>


#define SHA1_SIZE 20
#define BLOCK 8
#define ERR -1

int mafile()
{
        int j;
        int i;
        int power=1;
        char str[10];
        int outfd;

        for(i=1;i<8;i++)
        {
                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.txt",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file1\n");

                power <<=3;
                for (j=0;j<power;j++)
                        write(outfd,"A",1);
                close(outfd);

                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.sha1",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file2\n");
                close(outfd);
        }
        system("chmod 600 file*");
}

int main()
{
	int i;
	int infd,outfd;
	int bytes_read,bytes_write;
	float acum=0.0;
	struct timeval  start,end,lapsed;
	char stri[10],stro[10];
	unsigned char rbuff[BLOCK];
	unsigned char wbuff[SHA1_SIZE];
	SHA_CTX	c;

	mafile();
	memset(wbuff,0,sizeof(wbuff));
	memset(rbuff,0,sizeof(rbuff));

	SHA1_Init(&c);
	SHA1_Update(&c,rbuff,sizeof(rbuff));
	SHA1_Final(wbuff,&c);

        printf("SHA1 Digest\n");
        for (i=1;i<8;i++)
        {
                sprintf(stri,"file%d.txt",i);
                sprintf(stro,"file%d.sha1",i);

                if( (infd = open(stri,O_RDONLY)) == ERR)
                        printf("\nerror opening file1\n");

                if( (outfd = open(stro,O_WRONLY|O_CREAT,S_IWUSR)) == ERR)
                        printf("\nerror opening file2\n");

		memset(wbuff,0,sizeof(wbuff));
		memset(rbuff,0,sizeof(rbuff));

		SHA1_Init(&c);

		while( bytes_read = read(infd,rbuff,BLOCK) )
		{

			gettimeofday(&start,0);
			SHA1_Update(&c,rbuff,bytes_read);
			gettimeofday(&end,0);
			
                        if (start.tv_usec > end.tv_usec) {
                                end.tv_usec += 1000000;
                                end.tv_sec--;
                        }
                        lapsed.tv_usec = end.tv_usec - start.tv_usec;
                        acum += lapsed.tv_usec;

			memset(rbuff,0,BLOCK);
		}
	
		SHA1_Final(wbuff,&c);
		if( (bytes_write = write(outfd,wbuff,sizeof(wbuff))) == ERR)
			printf("\nerror writing to file2\n");

                printf("%f\n",acum);
                acum=0.0;
                close(infd);
                close(outfd);
	}
}
