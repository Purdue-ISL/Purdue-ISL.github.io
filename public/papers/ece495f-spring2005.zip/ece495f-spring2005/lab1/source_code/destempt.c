#include <openssl/des.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#define ERR -1
#define BLOCK 8
#define RSIZE 8
#define ENC 1
#define DEC 0

int mafile()
{
        int j;
        int i;
        int power=1;
        char str[10];
        int outfd;

        for(i=1;i<8;i++)
        {
                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.txt",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file1\n");

                power <<=3;
                for (j=0;j<(power/2);j++)
                        write(outfd,"X-",2);
                close(outfd);

                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.des",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file2\n");
                close(outfd);

                memset(str,NULL,sizeof(str));
                sprintf(str,"file%d.des.clr",i);
                if( (outfd = open(str,O_WRONLY|O_CREAT,S_IWUSR)) == -1)
                        printf("\nerror opening file3\n");
                close(outfd);

        }
        system("chmod 600 file*");
}

long pack(unsigned char *msg) 
{
	long lmsg;

	lmsg = (long)(*msg++);
	lmsg = (((long)(*msg++)) << 8) | lmsg;
	lmsg = (((long)(*msg++)) << 16) | lmsg;
	lmsg = (((long)(*msg++)) << 24) | lmsg;

	return(lmsg);
}

long packx(unsigned char *msg,int num)
{
	long lmsg = 0;
	int i;
	
	for (i=0;i<num;i++) {
		lmsg = (((long)(*msg++)) << (i*8)) | lmsg;
	}
	return(lmsg);
}

int unpack(long lmsg, unsigned char *msg)
{
	*(msg++) = (char)(lmsg & 0xff);
	*(msg++) = (char)((lmsg >> 8) & 0xff);
	*(msg++) = (char)((lmsg >> 16) & 0xff);
	*(msg++) = (char)((lmsg >> 24) & 0xff);
}

int main()
{
	int	infd,outfd,k,i,w;
	int	bytes_read,bytes_write;
	unsigned char	rbuff[BLOCK],wbuff[BLOCK];
	unsigned char	*in,*out,*iv;
	long	in1,in2;
	long	v1,v2;
	long	blk[2];
	long	fsize[10];
	struct timeval  start,end,lapsed;
	struct	stat	buffer;
	float	acum=0.0;
	char	stri[10],stro[10];	
	static unsigned char cbc_key[8] = {0x40,0xfe,0xdf,0x38,0x6d,0xa1,0x3d,0x57};
	static unsigned char cbc_iv[8] = {0xfe,0xdc,0xba,0x98,0x76,0x54,0x32,0x10};
	DES_key_schedule key;

	memset(rbuff,0,BLOCK);
	memset(wbuff,0,BLOCK);
	
	mafile();

	if ((k = DES_set_key_checked(&cbc_key,&key)) != 0)
		printf("\nkey error\n");

	blk[0] = 0;
	blk[1] = 0;
	DES_encrypt1(blk,&key,ENC);

        printf("DES encryption\n");
        for (i=1;i<8;i++)
        {
                sprintf(stri,"file%d.txt",i);
                sprintf(stro,"file%d.des",i);

		if( (infd = open(stri,O_RDONLY)) == ERR)
			printf("\nerror opening file1\n");

		fstat(infd,&buffer);
		fsize[i] = buffer.st_size;	

		if( (outfd = open(stro,O_WRONLY|O_CREAT,S_IWUSR)) == ERR)
			printf("\nerror opening file2\n");

		(unsigned char *)iv = &(cbc_iv[0]);
		v1 = pack(iv);
		v2 = pack(iv+4);

		while( (bytes_read = read(infd,rbuff,BLOCK)) )
		{
			(unsigned char *)in = &(rbuff[0]);

			if (bytes_read == BLOCK)
			{
				in1 = pack(in);
				in2 = pack(in+4);
			} else if (bytes_read <=4 ) {
				in1 = packx(in,bytes_read);
				in2 = 0;
			} else {
				in1 = packx(in,bytes_read);
				in2 = packx(in+4,bytes_read-4);
			}

			gettimeofday(&start,0);
			blk[0] = in1 ^ v1;
			blk[1] = in2 ^ v2;
			DES_encrypt1(blk,&key,ENC);
			gettimeofday(&end,0);

                	if (start.tv_usec > end.tv_usec) {
                        	end.tv_usec += 1000000;
                        	end.tv_sec--;
                	}
			
                	lapsed.tv_usec = end.tv_usec - start.tv_usec;
			acum += lapsed.tv_usec;

			(unsigned char *)out = &(wbuff[0]);
			unpack(blk[0],out);
			unpack(blk[1],out+4);

			if( (bytes_write = write(outfd,wbuff,BLOCK)) == ERR)
				printf("\nerror writing to file2\n");
		
			v1 = pack(out);
			v2 = pack(out+4);

			memset(rbuff,0,RSIZE);
			memset(wbuff,0,RSIZE);
		}
		printf("%f\n",acum);
		acum=0.0;
		close(infd);
		close(outfd);
	}

        printf("DES decryption\n");
        for (i=1;i<8;i++)
        {
                sprintf(stri,"file%d.des",i);
                sprintf(stro,"file%d.des.clr",i);

		if( (infd = open(stri,O_RDONLY)) == ERR)
                	printf("\nerror opening file1\n");

        	if( (outfd = open(stro,O_WRONLY|O_CREAT,S_IWUSR)) == ERR)
                	printf("\nerror opening file2\n");

		(unsigned char *)iv = &(cbc_iv[0]);
		v1 = pack(iv);
		v2 = pack(iv+4);

        	while( (bytes_read = read(infd,rbuff,BLOCK)) )
        	{
                	(unsigned char *)in = &(rbuff[0]);

			in1 = pack(in);
                	in2 = pack(in+4);
			blk[0] = in1;
			blk[1] = in2;

			gettimeofday(&start,0);
                	DES_encrypt1(blk,&key,DEC);
			blk[0] ^= v1;
			blk[1] ^= v2;
			gettimeofday(&end,0);

                	if (start.tv_usec > end.tv_usec) {
                        	end.tv_usec += 1000000;
                        	end.tv_sec--;
                	}
                	lapsed.tv_usec = end.tv_usec - start.tv_usec;
			acum += lapsed.tv_usec;

                	(unsigned char *)out = &(wbuff[0]);
                	unpack(blk[0],out);
                	unpack(blk[1],out+4);

			if(fsize[i] < BLOCK)
				w = fsize[i];
			else
				w = BLOCK;
	
                	if( (bytes_write = write(outfd,wbuff,w)) == ERR)
                        	printf("\nerror writing to file2\n");

			fsize[i] -= BLOCK;
                	v1 = in1;
                	v2 = in2;
                	memset(rbuff,0,RSIZE);
               	 	memset(wbuff,0,RSIZE);
        	}
		printf("%f\n",acum);
		acum=0.0;
        	close(infd);
        	close(outfd);
	}

}
