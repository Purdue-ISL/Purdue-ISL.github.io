#include "header.h"
#include <sys/stat.h>

struct genpacket
{
        short type;
        unsigned char payload[1008];
};
                                                                                                                                                             
unsigned char *to_hex(unsigned char *key,unsigned char test1[])
{
        char test[3];
        int i;
                                                                                                                                                             
        for(i=0;i<8;i++) {
                test[0] = *key++;
                test[1] = *key++;
                test1[i] = strtol(test,NULL,16);
        }
        return(test1);
}
                                                                                                                                                             
unsigned char *mysha1(char *file, unsigned char wbuff[]) {
        int i;
        int infd,outfd;
        int bytes_read,bytes_write;
        unsigned char rbuff[8];
        SHA_CTX c;
                                                                                                                                                             
        memset(wbuff,0,sizeof(wbuff));
        if( (infd = open(file,O_RDONLY)) == ERR)
                printf("\nerror opening file1\n");
        SHA1_Init(&c);
        while( bytes_read = read(infd,rbuff,sizeof(rbuff)) )
        {
                SHA1_Update(&c,rbuff,bytes_read);
                memset(rbuff,0,sizeof(rbuff));
        }
        SHA1_Final(wbuff,&c);
        return(wbuff);
}

int main(int argc, char **argv)
{
        int     sockfd;
        int     debug = 0;
        struct  sockaddr_in     servaddr, cliaddr;
        socklen_t len;
        unsigned short  port;
        struct  genpacket       generic;
        struct  ap_req          *apreq;
        struct  ap_rep          aprep;
        struct	ap_err		aperr;
	struct  ticket          tkt;
	struct  auth            authc;
        struct  krb_prv         *kenc_in, kenc_out;
        struct  pdata           pdata;
        DES_cblock      sesskey,ivec;
        DES_key_schedule key_ser;
        DES_key_schedule key_kcs;
	unsigned char cbc_bob[8];
        static unsigned char zero[8] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
        int     	i,j,k,trans;
	unsigned short tktsize,authsize,noncesize,prvsize;
        unsigned char 	*ptr,noncestr[20];
	unsigned long	nonce,validity,sender_ip;
	time_t	currtime;
        FILE    *fp;
        struct  stat    buffer,buf;
        short     pid;
        unsigned char   wbuff[SHA1_SIZE];
	int	bnonce = 0, whash=0;

        //check input arguments
        if ((argc < 4) || (argc > 9)) {
                printf("usage: server <serverport> <authserverkey> <inputfile>\n");
                exit(0);
        }

        if( ((argc == 5) || (argc == 7) || (argc == 9)) && (strcmp(argv[4],"-DDEBUG") == 0) ) {
                debug = 1;
        }
        if ( ((argc == 7) && ((strcmp(argv[5],"-T1") == 0))) || ((argc == 9) && ((strcmp(argv[7],"-T1") == 0))) ) {
                if (argc == 7)
                        bnonce = atoi(argv[6]);
                else
                        bnonce = atoi(argv[8]);
        }
        if ( ((argc == 7) && ((strcmp(argv[5],"-T2") == 0))) || ((argc == 9) && ((strcmp(argv[7],"-T2") == 0))) ) {
                        whash = 1;
        }

        //get the keys from the command line argument
        to_hex(argv[2],cbc_bob);

        port = atoi(argv[1]);
        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family     = AF_INET;
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        servaddr.sin_port       = htons(port);
        len = sizeof(cliaddr);

        if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == ERR) {
                if(debug) {
                        printf("Error while opening socket\n");
                }
                printf("ABORT\n");
                exit(0);
        }

        if ( (bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
                if(debug) {
                        printf("Error binding to socket\n");
                }
                printf("ABORT\n");
                exit(0);
        }

        //Set the key for BOB
        if ((j = DES_set_key_checked(&cbc_bob,&key_ser)) != 0)
        {
                if(debug) {
                        printf("Incorrect predefined authserver key\n");
                }
                printf("ABORT\n");
                exit(0);
        }

	memcpy(ivec,zero,sizeof(zero));

        for ( ; ; ) {
                bzero(&generic, sizeof(generic));
                if ( recvfrom(sockfd, &generic, sizeof(generic),0, (struct sockaddr *) &cliaddr, &len) == ERR) {
                        if(debug) {
                                printf("error receiving packet\n");
                        }
                        printf("ABORT\n");
                        exit(0);
                }
                if (ntohs(generic.type) != AP_REQ) {
                        if(debug) {
                                printf("First packet is not AP_REQ\n");
                        	printf("I'm receiving packet type = %d\n",ntohs(generic.type));
                        }
                        printf("ABORT\n");
                        exit(0);
                } else {
                        if(debug) {
                                printf("AP_REQ received\n");
                        }
                }

                // Getting the fields from AP_REQ
                apreq = (struct ap_req *) &generic;
        	tktsize = ntohs(apreq->tkt_length);		//size of ticket

        	//getting space for ticket
        	bzero(&tkt,sizeof(struct ticket));
		memcpy(ivec,zero,sizeof(zero));
        	DES_ncbc_encrypt(apreq->tkt_serv,(unsigned char *)&tkt,tktsize,&key_ser,&ivec,DES_DECRYPT);

        	//get session key
        	memcpy(&sesskey,tkt.kcs,sizeof(tkt.kcs));
		
        	//check Session key
        	if ((j = DES_set_key_checked(&sesskey,&key_kcs)) != 0)
        	{
                	printf("key error %d\n",j);
                	exit(0);
        	}

        	//check server ID on ticket
/*        	if (memcmp(tkt.server_id,SNAME,sizeof(SNAME)) == 0)
        	{
                	if (debug) {
                       	 	printf("Server ID is correct on ticket\n");
                	}
        	} else {
                	if (debug) {
                        	printf("Server ID is wrong on ticket\n");
                	}
                	exit(0);
        	}
*/
        	//check lifetime of session key (ticket)
       	 	time(&currtime);
	
		//store expiration time of the ticket on a local variable
		validity = (tkt.ts2) + ntohs(tkt.lt2);
        	if(currtime < (validity))
        	{
                	if (debug) {
                        	printf("Session key still valid\n");
                	}
        	} else {
                	if (debug) {
                        	printf("Session key has expired\n");
                        	printf("currtime = %u, validity = %u \n",currtime,validity);
                	}
                	exit(0);
        	}

       	 	//getting authenticator
        	bzero(&authc,sizeof(struct auth));
		authsize = ntohs(apreq->auth_length);
		memcpy(ivec,zero,sizeof(zero));
        	DES_ncbc_encrypt(apreq->auth,(unsigned char *)&authc,authsize,&key_kcs,&ivec,DES_DECRYPT);

		//checking name of client
                if ((memcmp(authc.client_id,tkt.client_id,sizeof(tkt.client_id)) == 0))
                {
                        if (debug) {
                                printf("Client name is correct\n");
                        }
                } else {
                        if (debug) {
                                printf("Client name is wrong. Im expecting %s but receiving %s\n",tkt.client_id,authc.client_id);
                                printf("Sending AP_ERR back to client\n");
                        }

                        bzero(&aperr,sizeof(struct ap_err));
                        aperr.type = htons(AP_ERR);
                        if ( (sendto(sockfd,&aperr,sizeof(aperr),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
                                if(debug) {
                                        printf("Error - packet size too long\n");
                                }
                                printf("ABORT\n");
                                exit(0);
                        }

			printf("ABORT\n");
			exit(0);
                }

		//checking IP address of client
		if (tkt.client_ipadd == authc.client_ipadd)
                {
                        if (debug) {
                                printf("Client IP address is correct\n");
                        }
                } else {
                        if (debug) {
                                printf("Client IP address is wrong\n");
				printf("Expecting %u but receiving %u\n",tkt.client_ipadd,authc.client_ipadd);
                        }
			bzero(&aperr,sizeof(struct ap_err));
                        aperr.type = htons(AP_ERR);
                        if ( (sendto(sockfd,&aperr,sizeof(aperr),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
                                if(debug) {
                                        printf("Error - packet size too long\n");
                                }
                                printf("ABORT\n");
                                exit(0);
                        }
                                                                                                                                                             
                        printf("ABORT\n");
                        exit(0);
                }

		//store client IP address in a local variable
		sender_ip = tkt.client_ipadd;

		//Generating nonce reponse
		nonce = authc.ts3;
		if(debug) {
			printf("nonce received = %d\n",nonce);
		}
		nonce += 1;
		
		/* Test case modification */
		nonce +=bnonce;
		if (debug){
			printf("nonce+1 after adding %d = %d\n", bnonce, nonce);
		}
		/* End modification */

		noncesize = sprintf(noncestr,"%d",nonce);

        	//Preparing AP_REP message
        	bzero(&aprep,sizeof(struct ap_rep));
        	aprep.type = htons(AP_REP);

                if ((noncesize % 8) != 0) {
                        noncesize += 4;
                }
		memcpy(ivec,zero,sizeof(zero));
		DES_ncbc_encrypt((unsigned char *)&noncestr,(unsigned char *)&aprep.nonce,noncesize,&key_kcs,&ivec,DES_ENCRYPT);

		aprep.nonce_length = htons(noncesize);
		//Sending AP_REP
                if ( (trans = sendto(sockfd,&aprep,sizeof(aprep),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
                        if(debug) {
                                printf("Error - packet size too long\n");
                        }
                        printf("ABORT\n");
                        exit(0);
                }
		if(debug) {
			printf("Sending AP_REP\n");
		}
//-------- Authentication is done -----------

		//Receiving APP_DATA_REQ application packet enc in a KRB_PRV packet
                bzero(&generic, sizeof(generic));
                if ( (recvfrom(sockfd, &generic, sizeof(generic),0, (struct sockaddr *) &cliaddr, &len)) == ERR) {
                        if(debug) {
                                printf("error receiving packet\n");
                        }
                        printf("ABORT\n");
                        exit(0);
                }

                if (ntohs(generic.type) == KRB_PRV) {
                        if(debug) {
                                printf("KRB_PRV received\n");
                        }
                } else if (ntohs(generic.type) == AP_ERR) {
                        if(debug) {
                                printf("AP_ERR received - aborting\n");
                        }
                        printf("ABORT\n");
                        exit(0);
                } else {
			if(debug) {
				printf("Expecting KRB_PRV or AP_ERR\n");
				printf("I'm receiving packet type = %d\n",ntohs(generic.type));
			}
                        printf("ABORT\n");
                        exit(0);
		}

        	//check lifetime of session key (ticket)
       	 	time(&currtime);
        	if(currtime < validity)
        	{
                	if (debug) {
                        	printf("Session key still valid\n");
                	}
        	} else {
                	if (debug) {
                        	printf("Session key has expired\n");
				printf("currtime = %u, expiration = %u \n",currtime,validity);
                	}
                	exit(0);
        	}

		//Opening KRB_PRV packet
		kenc_in = (struct krb_prv *) &generic;
                prvsize = ntohs(kenc_in->prv_length);	//size of ticket

                //getting space for data
		bzero(&pdata,sizeof(struct pdata));
		memcpy(ivec,zero,sizeof(zero));
		DES_ncbc_encrypt(kenc_in->prv,(unsigned char *)&pdata,prvsize,&key_kcs,&ivec,DES_DECRYPT);

		//geting DATA packet
		if (ntohs(pdata.type) != APP_DATA_REQ) {
                        if(debug) {
                                printf("Expecting APP_DATA_REQ\n");
				printf("I'm receiving packet type = %d\n",ntohs(pdata.type));
                        }
                        printf("ABORT\n");
                        exit(0);
                } else {
                        if(debug) {
                                printf("APP_DATA_REQ received\n");
                        }
                }

		//Forming DATA packet
                fp = fopen(argv[3],"r");
                stat(argv[3],&buffer);
                pid = 0;
                while(feof(fp) == 0) {
		//loading data to pdata struct
			bzero(&kenc_out,sizeof(struct krb_prv));
                	bzero(&pdata, sizeof(struct pdata));
                	pdata.type = htons(APP_DATA);
                        pdata.packet_length = htons(fread(pdata.data,sizeof(char),sizeof(pdata.data),fp));
                        pdata.pid = htons(++pid);

		//preparing KRB_PRV packet
			kenc_out.type = htons(KRB_PRV);
			kenc_out.prv_length = htons(sizeof(struct pdata));
                	memcpy(ivec,zero,sizeof(zero));
                	DES_ncbc_encrypt((unsigned char *)&pdata,(unsigned char *)&kenc_out.prv,sizeof(struct pdata),&key_kcs,&ivec,DES_ENCRYPT);
		
		//send DATA packet	
                        if ( (sendto(sockfd,&kenc_out,sizeof(struct krb_prv),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
                                if(debug) {
                                        printf("Error - packet size too long\n");
                                }
                                printf("ABORT\n");
                                exit(0);
                        }
                        if(debug) {
                                printf("sending file!\n");
                        }
                }

                if(debug) {
                        printf("file sended!\n");
                }
                fclose(fp);

		//Get and send the file digest
                mysha1(argv[3],wbuff);

		/* test case wrong hash */
		if(whash) {
                        memcpy(wbuff,"Wrong Hash",12);
			if (debug) {
				printf("%s\n",wbuff);
			}
		}
                //end testcase



		bzero(&kenc_out,sizeof(struct krb_prv));
 		bzero(&pdata, sizeof(struct pdata));

		//loading data to pdata struct
  		pdata.type = htons(APP_TERMINATE);
		memcpy(pdata.data,wbuff,sizeof(wbuff));
		pdata.packet_length = htons(sizeof(wbuff));

               //preparing KRB_PRV packet
  		kenc_out.type = htons(KRB_PRV);
 	 	kenc_out.prv_length = htons(sizeof(struct pdata));
		memcpy(ivec,zero,sizeof(zero));
		DES_ncbc_encrypt((unsigned char *)&pdata,(unsigned char *)&kenc_out.prv,sizeof(struct pdata),&key_kcs,&ivec,DES_ENCRYPT);

                //send TERMINATE packet
 		if ( (sendto(sockfd,&kenc_out,sizeof(struct krb_prv),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
  			if(debug) {
        			printf("Error - packet size too long\n");
    			}
   	 		printf("ABORT\n");
   			exit(0);
   		}

		if(debug) {
      			printf("file digest sent!\n");
		}

		printf("OK\n");
	}
}
