#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <sys/stat.h>
#include <openssl/sha.h>
#include <fcntl.h>
#include <netdb.h>
#include <math.h>

#define SHA1_SIZE	20
#define PASS_SIZE	50
#define	BLOCK_SIZE	1000
#define ERR 		-1
#define JOIN_REQ        1
#define PASS_REQ        2
#define PASS_RESP       3
#define PASS_ACCEPT     4
#define DATA            5
#define TERMINATE	6
#define REJECT      	7

struct genpacket
{
        short   header;
        int     plength;
//        int     fsize;
        int     pid;
        unsigned char    data[BLOCK_SIZE];
};

struct pdata
{
        short   header;
        int     plength;
        //int     fsize;
        int     pid;
        unsigned char    data[BLOCK_SIZE];
};
struct ppass
{
        short   header;
        int     plength;
        unsigned char    data[PASS_SIZE];
};
struct pterm
{
        short   header;
        int     plength;
        unsigned char    data[SHA1_SIZE];
};
struct jr
{
	short   header;
	int     plength;
};
struct pr
{
	short   header;
	int     plength;
};
struct pa
{
	short   header;
	int     plength;
};
struct rej
{
	short   header;
	int     plength;
};

unsigned char *mysha1(char *file, unsigned char wbuff[]) {
        int i;
        int infd,outfd;
        int bytes_read,bytes_write;
        unsigned char rbuff[8];
        SHA_CTX c;

        memset(wbuff,0,sizeof(wbuff));
        if( (infd = open(file,O_RDONLY)) == ERR)
                printf("\nerror opening file1\n");
        SHA1_Init(&c);
        while( bytes_read = read(infd,rbuff,sizeof(rbuff)) )
        {
                SHA1_Update(&c,rbuff,bytes_read);
                memset(rbuff,0,sizeof(rbuff));
        }
        SHA1_Final(wbuff,&c);
	return(wbuff);
}

unsigned short to_num(unsigned char *key)
{
        int i=0,num=0;
        unsigned short tests=0,acums=0;

        while( *(key+i) != '\0' ) {
                i++;
        }

        num = i;
        for(i=(num-1);i>=0;i--) {
                tests = (int) *key++;
                tests -= 48;
                tests *= pow(10,i);
                acums += tests;
                tests = 0;
        }
        return(acums);
}

unsigned short size(unsigned char *key)
{
        int i=0,num=0;

        while( *(key+i) != '\0' ) {
                i++;
        }
	return(i);
}


int main(int argc, char **argv)
{
	int	sockfd;
	int	debug = 0;
	int	n,i,counter;
	struct 	sockaddr_in	servaddr, cliaddr;
	socklen_t len;
	FILE	*fp;
	struct  stat    buffer,buf;
	int	pid;
	unsigned char	wbuff[SHA1_SIZE];
	unsigned short	port;
	struct	genpacket	recvpacket;
	struct	pdata	pdata;
	struct	ppass	*ppass;
	struct	pterm	pterm;
	struct	jr	jr;
	struct	pr	pr;
	struct	pa	pa;
	struct	rej	rej;	

	if ((argc < 4) || (argc > 5)) {
		printf("usage: udpserv <serverport> <password> <input file>\n");
		exit(0);
	}

	i = stat(argv[3],&buf);
	if (i != 0) {
         	printf("Input file doesn't exist\n");
		exit(0);
	}

	if((argc == 5) && (strcmp(argv[4],"-DDEBUG") == 0)) {
		debug = 1;
	}

	port = to_num(argv[1]);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family	= AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port 	= htons(port);
	len = sizeof(cliaddr);

        if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == ERR) {
		if(debug) {
                	printf("Error while opening socket\n");
		}
		printf("ABORT\n");
                exit(0);
        }

	if ( (bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
		if(debug) {
			printf("Error binding to socket\n");
		}
		printf("ABORT\n");
		exit(0);
	}

	for ( ; ; ) {

        	bzero(&recvpacket, sizeof(recvpacket));
		
        	if ( recvfrom(sockfd, &recvpacket, sizeof(recvpacket),0, (struct sockaddr *) &cliaddr, &len) == ERR) { 
			if(debug) {
                		printf("error receiving packet\n");
			}
			printf("ABORT\n");
                	exit(0);
        	}
		if ((ntohs(recvpacket.header) != JOIN_REQ) && (recvpacket.plength != 0)) {
			if(debug) {
				printf("First packet is not JOIN_REQ\n");
			}
			printf("ABORT\n");
			exit(0);
		} else {
			if(debug) {
				printf("JOIN_REQ received\n");
			}
		}
        	bzero(&pr, sizeof(pr));
        	pr.header   = htons(PASS_REQ);
        	pr.plength  = 0;

        	if ( (sendto(sockfd,&pr,sizeof(pr),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
			if(debug) {
                		printf("Error - packet size too long\n");
			}
			printf("ABORT\n");
                	exit(0);
        	}

        	bzero(&recvpacket, sizeof(recvpacket));

        	if ( recvfrom(sockfd, &recvpacket, sizeof(recvpacket),0, (struct sockaddr *) &cliaddr, &len) == ERR) { 
			if(debug) {
                		printf("error receiving packet\n");
			}
			printf("ABORT\n");
                	exit(0);
		}

		if ((ntohs(recvpacket.header) != PASS_RESP) && (ntohl(recvpacket.plength) > sizeof(ppass->data))) {
			if(debug) {
				printf("Im expecting PASS_RESP\n");
			}
			printf("ABORT\n");
			exit(0);
		} else {
			if(debug) {
				printf("PASS_RESP received\n");
			}
		}
		ppass = (struct ppass *) &recvpacket;
			if(debug) {
				printf("Im getting %s\n",ppass->data);
			}

		counter = 0;

		while( (memcmp(ppass->data,argv[2],size(argv[2])) != 0) || (ntohl(ppass->plength) != size(argv[2])) ) {
			if(debug) {
				printf("password not correct\n");
			}
			counter+=1;

			if (counter >= 3) {
        			bzero(&rej, sizeof(rej));
        			rej.header = htons(REJECT);
        			rej.plength  = 0;

        			if ( (sendto(sockfd,&rej,sizeof(rej),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
					if(debug) {
                				printf("Error - packet size too long\n");
					}
					printf("ABORT\n");
                			exit(0);
        			}
				printf("ABORT\n");
				exit(0);
			}

        		bzero(&pr, sizeof(pr));
        		pr.header   = htons(PASS_REQ);
        		pr.plength  = 0;

        		if ( (sendto(sockfd,&pr,sizeof(pr),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
				if(debug) {
                			printf("Error - packet size too long\n");
				}
				printf("ABORT\n");
                		exit(0);
        		}
        		if ( recvfrom(sockfd, &recvpacket, sizeof(recvpacket),0, (struct sockaddr *) &cliaddr, &len) == ERR) { 
				if(debug) {
                			printf("error receiving packet\n");
				}
				printf("ABORT\n");
                		exit(0);
			}

			if ((ntohs(recvpacket.header) != PASS_RESP) && (ntohl(recvpacket.plength) > sizeof(ppass->data))) {
				if(debug) {
					printf("Im expecting PASS_RESP\n");
				}
				printf("ABORT\n");
				exit(0);
			} else {
				if(debug) {
					printf("PASS_RESP received\n");
				}
			}
			ppass = (struct ppass *) &recvpacket;
			if(debug) {
				printf("Im getting %s\n",ppass->data);
			}
		}
	
		if(debug) {
			printf("password correct\n");
		}

        	bzero(&pa, sizeof(pa));
        	pa.header   = htons(PASS_ACCEPT);
        	pa.plength  = 0;
        	if ( (sendto(sockfd,&pa,sizeof(pa),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
			if(debug) {
                		printf("Error - packet size too long\n");
			}
			printf("ABORT\n");
                	exit(0);
        	}

        	bzero(&pdata, sizeof(pdata));
        	pdata.header = htons(DATA);

		fp = fopen(argv[3],"r");
		stat(argv[3],&buffer);
//        	pdata.fsize = htonl(buffer.st_size);
		pid = 0;
		while(feof(fp) == 0) {
			pdata.plength = htonl(fread(pdata.data,sizeof(char),sizeof(pdata.data),fp));
			pdata.pid = htonl(++pid);
                        if ( (sendto(sockfd,&pdata,sizeof(pdata),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
				if(debug) {
                                	printf("Error - packet size too long\n");
				}
				printf("ABORT\n");
                                exit(0);
                        }
			bzero(&pdata, sizeof(pdata));
			pdata.header = htons(DATA);
//			pdata.fsize = htonl(buffer.st_size);
			if(debug) {
				printf("sending file!\n");
			}
		}

		if(debug) {
			printf("file sended!\n");
		}

		fclose(fp);
	
		mysha1(argv[3],wbuff);
		// RDT -Change
			memcpy(wbuff,"Wrong Hash",12);
		//END

		bzero(&pterm, sizeof(pterm));
		pterm.header = htons(TERMINATE);
		memcpy(pterm.data,wbuff,sizeof(wbuff));
		pterm.plength = htonl(sizeof(wbuff));
        	if ( (sendto(sockfd,&pterm,sizeof(pterm),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
			if(debug) {
                		printf("Error - packet size too long\n");
			}
			printf("ABORT\n");
                	exit(0);
        	}
		
		printf("OK\n");
	}
}
