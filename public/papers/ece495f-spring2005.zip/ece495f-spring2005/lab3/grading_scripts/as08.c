#include "header.h"

struct genpacket
{
        short type;
        unsigned char payload[1008];
};
                                                                                
unsigned char *to_hex(unsigned char *key,unsigned char test1[])
{
        char test[3];
        int i;
                                                                                
        for(i=0;i<8;i++) {
                test[0] = *key++;
                test[1] = *key++;
                test1[i] = strtol(test,NULL,16);
        }
        return(test1);
}

int main(int argc, char **argv)
{
        int     sockfd;
        int     debug = 0;
        struct  sockaddr_in     servaddr, cliaddr;
        socklen_t len;
        unsigned short  port;
        struct  genpacket       generic;
	struct	as_req		*asreq;
	struct	as_rep		asrep;
	struct	as_err		aserr;
	struct	credential	crede;
	struct	ticket		tkt;
        static const char rnd_seed[] = "string to make the random number generator think it has entropy";
	DES_cblock	sesskey, ivec;
	DES_key_schedule key_ser;
	DES_key_schedule key_cli;
	DES_key_schedule key_kcs;
	unsigned char cbc_bob[8];
	unsigned char cbc_alice[8];
	static unsigned char zero[8] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
	int	i,j,k,tktsize,credsize,trans;
	unsigned char *ptr,client_id[40],server_id[40];

	//check input arguments
        if ((argc < 6) || (argc > 7)) {
                printf("usage: authserv <authserverport> <clientID> <clientkey> <serverID> <serverkey>\n");
                exit(0);
        }

        if((argc == 7) && (strcmp(argv[6],"-DDEBUG") == 0)) {
                debug = 1;
        }

	//get client en server ID from command line;
        bzero(&client_id, sizeof(client_id));
        bzero(&server_id, sizeof(server_id));
	strcpy(client_id,argv[2]);
	strcpy(server_id,argv[4]);

        //get the keys from the command line argument
        to_hex(argv[3],cbc_alice);
	to_hex(argv[5],cbc_bob);

        port = atoi(argv[1]);
        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family     = AF_INET;
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        servaddr.sin_port       = htons(port);
        len = sizeof(cliaddr);

        if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == ERR) {
                if(debug) {
                        printf("Error while opening socket\n");
                }
                printf("ABORT\n");
                exit(0);
        }

        if ( (bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))) == ERR) {
                if(debug) {
                        printf("Error binding to socket\n");
                }
                printf("ABORT\n");
                exit(0);
        }

	//Set the keys for BOB and ALICE
	if ((j = DES_set_key_checked(&cbc_bob,&key_ser)) != 0)
	{
		if(debug) {
			printf("Incorrect predefined server key \n");
		}
		printf("ABORT\n");
		exit(0);
	}

	if ((j = DES_set_key_checked(&cbc_alice,&key_cli)) != 0)
	{
		if(debug) {
			printf("Incorrect predefined client key \n");
		}
		printf("ABORT\n");
		exit(0);
	}

	memcpy(ivec,zero,sizeof(zero));

	//Initialize random number generator
	RAND_seed(rnd_seed, sizeof rnd_seed);

        for ( ; ; ) {
                bzero(&generic, sizeof(generic));
                if ( recvfrom(sockfd, &generic, sizeof(generic),0, (struct sockaddr *) &cliaddr, &len) == ERR) {
                        if(debug) {
                                printf("error receiving packet\n");
                        }
                        printf("ABORT\n");
                        exit(0);
 		}
                if (ntohs(generic.type) != AS_REQ) {
                        if(debug) {
                                printf("First packet is not AS_REQ\n");
                                printf("I'm receiving packet type = %d\n",ntohs(generic.type));

                        }
                        printf("ABORT\n");
                        exit(0);
                } else {
                        if(debug) {
                                printf("AS_REQ received\n");
                        }
			
                }
		// Getting the fields from the packet
		asreq = (struct as_req *) &generic;

		// Check if IDC and IDS are valid
		if ((memcmp(asreq->client_id,client_id,sizeof(client_id)) == 0) 
		&& (memcmp(asreq->server_id,server_id,sizeof(server_id)) == 0)) 
		{
			if (debug) {
				printf("Client and Server IDs correct\n");
			}
		} else {
			if (debug) {
				printf("Client or server info is wrong. Im receiving client = %s and server = %s\n",asreq->client_id,asreq->server_id);
				printf("But Im expecting client = %s and server = %s\n",client_id,server_id);
				printf("Sending AS_ERR back to client\n");
			}
		//sending AS_ERR to client
			bzero(&aserr,sizeof(struct as_err));
			aserr.type = htons(AS_ERR);
			memcpy(aserr.client_id,asreq->client_id,sizeof(aserr.client_id));
                	if ( (sendto(sockfd,&aserr,sizeof(aserr),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
                        	if(debug) {
                                	printf("Error - packet size too long\n");
                        	}
                        	printf("ABORT\n");
                        	exit(0);
			}
                        printf("ABORT\n");
                        exit(0);
		}
		
		// Generate session key for client and server
		DES_random_key(&sesskey);

		if ((j = DES_set_key_checked(&sesskey,&key_kcs)) != 0)
		{
			if(debug) {
				printf("Wrong session key generated\n");
				printf("Session key generated:\t");
				for (i=0;i<sizeof(sesskey);i++) {
					printf("%x",sesskey[i]);
				}
				printf("\n");
			}
			printf("ABORT\n");
			exit(0);
		}
		
		if(debug) {
			printf("Session key generated:\t");
			for (i=0;i<sizeof(sesskey);i++) {
				printf("%x",sesskey[i]);
			}
			printf("\n");
		}

		//generate ticket for server
		bzero(&tkt,sizeof(struct ticket));
		memcpy(tkt.kcs,sesskey,sizeof(sesskey));		//copying session key
		memcpy(tkt.client_id,client_id,sizeof(client_id));	//copying client ID
		tkt.client_ipadd = cliaddr.sin_addr.s_addr;	//copying client IPadd

		if(debug) {
			printf("client ip address in network byte order  = %u\n",tkt.client_ipadd);
		}

		memcpy(tkt.server_id,server_id,sizeof(server_id));	//copying server ID
		time(&tkt.ts2);						//getting the timestamp
		if(debug) {
			printf("timestamp for session key = %u\n",tkt.ts2);
		}

		tkt.lt2 = htons(LIFETIME);				//lifetime

		//generate credential for client
		bzero(&crede,sizeof(struct credential));
	
		//make space for encrypted ticket
		tktsize = sizeof(struct ticket);
		if ((tktsize % 8) != 0) {
			tktsize += 4;
		} 

		memcpy(ivec,zero,sizeof(zero));	
		DES_ncbc_encrypt((unsigned char *)&tkt,(unsigned char *)&crede.tkt_serv,sizeof(struct ticket),&key_ser,&ivec,DES_ENCRYPT);

		memcpy(crede.kcs,sesskey,sizeof(sesskey));
		memcpy(crede.server_id,server_id,sizeof(server_id));
		crede.ts2 = tkt.ts2;
		crede.lt2 = htons(LIFETIME);
		crede.tkt_length = htons(tktsize);

		//form AS_REP packet
		bzero(&asrep,sizeof(struct as_rep));
		
		//make space for message to user
		credsize = sizeof(struct credential);
		if ((credsize % 8) != 0) {
			credsize += 4;
		}

		//encrypt credential
		memcpy(ivec,zero,sizeof(zero));	
		DES_ncbc_encrypt((unsigned char *)&crede,(unsigned char *)&asrep.cred,sizeof(struct credential),&key_cli,&ivec,DES_ENCRYPT);

		asrep.type = htons(AS_REP);
		asrep.cred_length = htons(credsize);

		//sending AS_REQ to client
                if ( (trans = sendto(sockfd,&asrep,sizeof(asrep),0, (struct sockaddr *) &cliaddr, sizeof(cliaddr))) == ERR) {
                        if(debug) {
                                printf("Error - packet size too long\n");
                        }
                        printf("ABORT\n");
                        exit(0);
                }
		if(debug) {
			printf("Sending AS_REP message\n");
		}
		printf("OK\n");
	}
}
